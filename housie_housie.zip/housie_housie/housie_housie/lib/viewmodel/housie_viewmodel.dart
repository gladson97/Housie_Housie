import 'dart:math';

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

class HousieViewmodel extends ChangeNotifier {
  static final provider = ChangeNotifierProvider<HousieViewmodel>((ref) {
    return HousieViewmodel();
  });

  List<int> rolledNumbers = [];
  int? currentNumber;
  int total = 90;

  void roll() {
    if (rolledNumbers.length != total) {
      currentNumber = Random().nextInt(total) + 1;

      if (rolledNumbers.contains(currentNumber)) {
        return roll();
      }
      rolledNumbers.add(currentNumber!);
    }

    notifyListeners();
  }

  void restart() {
    rolledNumbers.clear();
    currentNumber = null;
    notifyListeners();
  }
}
