import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:housie_housie/viewmodel/housie_viewmodel.dart';

class HousiePage extends ConsumerStatefulWidget {
  const HousiePage({super.key});

  @override
  ConsumerState<ConsumerStatefulWidget> createState() => _HousiePageState();
}

class _HousiePageState extends ConsumerState<HousiePage> {
  @override
  Widget build(BuildContext context) {
    final viewmodel = ref.watch(HousieViewmodel.provider);
    return SafeArea(
      child: Scaffold(
          backgroundColor: Colors.amber,
          body: Column(
            children: [
              const Padding(
                padding: EdgeInsets.all(8.0),
                child: Text(
                  "Housie Housie",
                  style: TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.bold,
                      fontSize: 24),
                ),
              ),
              Expanded(
                flex: 3,
                child: Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: GridView.builder(
                    itemCount: 90,
                    gridDelegate:
                        const SliverGridDelegateWithFixedCrossAxisCount(
                            crossAxisCount: 9),
                    itemBuilder: (context, index) {
                      return Card(
                          color: viewmodel.rolledNumbers.contains(index + 1)
                              ? Colors.grey
                              : Colors.white,
                          child: Center(
                            child: Text(
                              (index + 1).toString(),
                              textAlign: TextAlign.center,
                            ),
                          ));
                    },
                  ),
                ),
              ),
              Expanded(
                  child: Column(
                children: [
                  // Text(viewmodel.rolledNumbers.toString()),

                  Text(
                    viewmodel.rolledNumbers.length == viewmodel.total
                        ? "Game finished"
                        : viewmodel.currentNumber?.toString() ?? "Let's Roll",
                    style: const TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.bold,
                        fontSize: 24),
                  ),
                  const SizedBox(
                    height: 20,
                  ),
                  viewmodel.rolledNumbers.length == viewmodel.total
                      ? ElevatedButton(
                          onPressed: () {
                            viewmodel.restart();
                          },
                          style: ButtonStyle(
                              backgroundColor: MaterialStateProperty.all<Color>(
                                  Colors.white),
                              foregroundColor: MaterialStateProperty.all<Color>(
                                  Colors.amber),
                              padding: MaterialStateProperty.all<EdgeInsets>(
                                  const EdgeInsets.symmetric(horizontal: 50))),
                          child: const Text("Restart"),
                        )
                      : ElevatedButton(
                          onPressed: () {
                            viewmodel.roll();
                          },
                          style: ButtonStyle(
                              backgroundColor: MaterialStateProperty.all<Color>(
                                  Colors.white),
                              foregroundColor: MaterialStateProperty.all<Color>(
                                  Colors.amber),
                              padding: MaterialStateProperty.all<EdgeInsets>(
                                  const EdgeInsets.symmetric(horizontal: 50))),
                          child: const Text("Pick"),
                        )
                ],
              ))
            ],
          ),
          floatingActionButton: viewmodel.rolledNumbers.isNotEmpty
              ? FloatingActionButton(
                  backgroundColor: Colors.white,
                  onPressed: () {
                    showModalBottomSheet(
                        context: context,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(10.0),
                        ),
                        builder: (context) {
                          return Column(
                            children: [
                              const Padding(
                                padding: EdgeInsets.all(8.0),
                                child: Text(
                                  "Number Track",
                                  style: TextStyle(
                                      color: Colors.amber,
                                      fontWeight: FontWeight.bold,
                                      fontSize: 24),
                                ),
                              ),
                              const SizedBox(
                                height: 25,
                              ),

                              Wrap(children: [
                                for (var val in viewmodel.rolledNumbers)
                                  SizedBox(
                                    width: 40,
                                    child: Card(
                                      child: Padding(
                                        padding: const EdgeInsets.all(8.0),
                                        child: Center(
                                          child: Text(
                                            val.toString(),
                                            textAlign: TextAlign.center,
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                              ])
                              // Text(viewmodel.rolledNumbers.toString())
                            ],
                          );
                        });
                  },
                  child: const Icon(
                    Icons.follow_the_signs,
                    color: Colors.amber,
                  ),
                )
              : Container()),
    );
  }
}
