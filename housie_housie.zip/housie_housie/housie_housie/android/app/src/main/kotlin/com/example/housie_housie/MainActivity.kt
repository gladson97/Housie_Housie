package com.example.housie_housie

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
